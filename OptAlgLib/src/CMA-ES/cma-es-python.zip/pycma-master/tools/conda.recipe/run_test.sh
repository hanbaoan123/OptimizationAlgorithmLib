#!/bin/bash

python -m cma.test
